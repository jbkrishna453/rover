package com.azira.rover;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.azira.rover.beans.Directions;
import com.azira.rover.beans.Environment;
import com.azira.rover.beans.RoverConfigurations;
import com.azira.rover.beans.RoverStatus;
import com.azira.rover.services.EnvironmentService;
import com.azira.rover.services.RoverConfigurationService;
import com.azira.rover.services.RoverException;

@RestController
public class RoverController {

	@Autowired
	private EnvironmentService envService;
	@Autowired
	private RoverConfigurationService roverConfigService;
	
	@PostMapping("/api/environment/configure")
	public void configureEnvironement(@RequestBody Environment environment) {
		envService.configure(environment);
	}
	@PostMapping("/api/environment")
	public void updateEnvironement(@RequestBody Environment environment) {
		 envService.update(environment);
	}
	@PostMapping("/api/rover/configure")
	public void configRoverConfigurations(@RequestBody RoverConfigurations roverConfigs) {
		roverConfigService.save(roverConfigs);
	}
	@PostMapping("/api/rover/move")
	public void moveRover(@RequestBody Directions directions)  throws RoverException{
			roverConfigService.move(directions);
		
	}
	@GetMapping("/api/rover/status")
	public ResponseEntity<RoverStatus> getStatus(){
		RoverStatus roverStatus= roverConfigService.getStatus();
		return new ResponseEntity<RoverStatus>(roverStatus,new HttpHeaders(),HttpStatus.OK);
	}
	@GetMapping("/getRoverConfigurations")
	public RoverConfigurations getRoverConfigurations() {
		return roverConfigService.roverConfigurations;
	}
}
