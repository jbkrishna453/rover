package com.azira.rover;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.azira.rover.beans.ErrorMessage;
import com.azira.rover.services.RoverException;

@ControllerAdvice
public class RoverExceptionHandler extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(RoverException.class)
	public final ResponseEntity<?> handleRoverException(RoverException ex){
		ErrorMessage errorMsg= new ErrorMessage(ex.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMsg,new HttpHeaders(),HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

}
