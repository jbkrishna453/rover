package com.azira.rover.beans;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Environment {
	private int temperature;
	private int humidity;
	@JsonProperty(value="solar-flare")
	private boolean solarFlare;
	private boolean storm;
	private String terrain;
	
	@JsonProperty(value="area-map")
	private ArrayList<ArrayList<TerrainType>> areaMap;
	
	
	public int getTemperature() {
		return temperature;
	}
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
	public int getHumidity() {
		return humidity;
	}
	public void setHumidity(int humidity) {
		this.humidity = humidity;
	}
	public boolean isSolarFlare() {
		return solarFlare;
	}
	public void setSolarFlare(boolean solarFlare) {
		this.solarFlare = solarFlare;
	}
	public boolean isStorm() {
		return storm;
	}
	public void setStorm(boolean storm) {
		this.storm = storm;
	}
	public ArrayList<ArrayList<TerrainType>> getAreaMap() {
		return areaMap;
	}
	public void setAreaMap(ArrayList<ArrayList<TerrainType>> areaMap) {
		this.areaMap = areaMap;
	}
	public String getTerrain() {
		return terrain;
	}
	public void setTerrain(String terrain) {
		this.terrain = terrain;
	}

}
