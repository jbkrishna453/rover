package com.azira.rover.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class Performs {

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "collect-sample")
	private CollectSample collectSample;
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "item-usage")
	private ItemUsuage itemUsuage;
	public ItemUsuage getItemUsuage() {
		return itemUsuage;
	}
	public void setItemUsuage(ItemUsuage itemUsuage) {
		this.itemUsuage = itemUsuage;
	}
	public CollectSample getCollectSample() {
		return collectSample;
	}
	public void setCollectSample(CollectSample collectSample) {
		this.collectSample = collectSample;
	}
	
}
