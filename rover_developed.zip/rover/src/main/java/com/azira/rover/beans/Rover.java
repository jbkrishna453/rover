package com.azira.rover.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class Rover {

	@JsonInclude(Include.NON_NULL)
	private String is;
	@JsonInclude(Include.NON_NULL)
	private Performs performs;
	public Performs getPerforms() {
		return performs;
	}
	public void setPerforms(Performs performs) {
		this.performs = performs;
	}
	public String getIs() {
		return is;
	}
	public void setIs(String is) {
		this.is = is;
	}
}
