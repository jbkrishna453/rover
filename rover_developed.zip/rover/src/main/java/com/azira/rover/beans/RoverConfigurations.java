package com.azira.rover.beans;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RoverConfigurations {

	private ArrayList<Scenarioas> scenarios;
	private ArrayList<States> states;
	@JsonProperty(value = "deploy-point")
	private DeployPoint deployPoint;
	@JsonProperty(value = "initial-battery")
	private int initialBattery ;
	private ArrayList<Inventory> inventory;
	public ArrayList<Scenarioas> getScenarios() {
		return scenarios;
	}
	public void setScenarios(ArrayList<Scenarioas> scenarios) {
		this.scenarios = scenarios;
	}
	public ArrayList<States> getStates() {
		return states;
	}
	public void setStates(ArrayList<States> states) {
		this.states = states;
	}
	public DeployPoint getDeployPoint() {
		return deployPoint;
	}
	public void setDeployPoint(DeployPoint deployPoint) {
		this.deployPoint = deployPoint;
	}
	public int getInitialBattery() {
		return initialBattery;
	}
	public void setInitialBattery(int initialBattery) {
		this.initialBattery = initialBattery;
	}
	public ArrayList<Inventory> getInventory() {
		return inventory;
	}
	public void setInventory(ArrayList<Inventory> inventory) {
		this.inventory = inventory;
	}
	
	
}
