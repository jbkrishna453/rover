package com.azira.rover.beans;

import java.util.ArrayList;

public class RoverResponse {
	
	private Location location;
	private int battery;
	private ArrayList<Inventory> inventory;
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public int getBattery() {
		return battery;
	}
	public void setBattery(int battery) {
		this.battery = battery;
	}
	public ArrayList<Inventory> getInventory() {
		return inventory;
	}
	public void setInventory(ArrayList<Inventory> inventory) {
		this.inventory = inventory;
	}
	
	
	

}
