package com.azira.rover.beans;

public class RoverStatus {

	private RoverResponse rover;
	private ResponseEnvironment environment;
	public RoverResponse getRover() {
		return rover;
	}
	public void setRover(RoverResponse rover) {
		this.rover = rover;
	}
	public ResponseEnvironment getEnvironment() {
		return environment;
	}
	public void setEnvironment(ResponseEnvironment environment) {
		this.environment = environment;
	}
	
}
