package com.azira.rover.beans;

public enum TerrainType {

	
		dirt("dirt") ,water("water") ,rock("rock") , sand("sand");

	 	private final String value;
		TerrainType(String value) {
			this.value = value;
		}
		
		public String getValue() {
			return value;
		}

	
	
}
