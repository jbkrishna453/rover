package com.azira.rover.services;

import org.springframework.stereotype.Component;

import com.azira.rover.beans.Environment;

@Component
public class EnvironmentService {

	public static Environment environment;
	static int maxColumn;
	static int maxRow;
	 
	 public void configure(Environment env) {
		if(environment==null)
			environment=new  Environment();
		environment=env;
		maxColumn=environment.getAreaMap().get(0).size()-1;
		maxRow=environment.getAreaMap().size()-1;
	}
	
	
	
	public void update(Environment env) {
		if(env.isSolarFlare()) {
			environment.setSolarFlare(true);
			RoverConfigurationService.battery=11;
			RoverConfigurationService.steps=0;
		}else if(env.isStorm())
			environment.setStorm(true);
		else if(!(env.getHumidity()==0))
			environment.setHumidity(env.getHumidity());
		else if(!(env.getTemperature()==0))
			environment.setTemperature(env.getTemperature());
		else if(!(env.getAreaMap()==null)) {
			environment.setAreaMap(env.getAreaMap());
			maxColumn=environment.getAreaMap().get(0).size();
			maxRow=environment.getAreaMap().size();
		}
	}
}
