package com.azira.rover.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Component;

import com.azira.rover.beans.DeployPoint;
import com.azira.rover.beans.Directions;
import com.azira.rover.beans.Inventory;
import com.azira.rover.beans.Location;
import com.azira.rover.beans.ResponseEnvironment;
import com.azira.rover.beans.RoverConfigurations;
import com.azira.rover.beans.RoverResponse;
import com.azira.rover.beans.RoverStatus;

@Component
public class RoverConfigurationService {

	public RoverConfigurations roverConfigurations;
	private static Location location;
	static int battery;
	static int steps=0;
	static HashMap<String,Inventory> inventoryMap= new HashMap<>();
	 static final Map<String, Integer> map = Stream.of(new Object[][] { 
	     { "storm-sheild", 1 },
	     { "water", 2 }, 
	     { "rock", 3 }
	 }).collect(Collectors.toMap(data -> (String) data[0], data -> (Integer) data[1]));
	static final int  maxSize=5;
	static  int  curSize=0;
	
	public void save(RoverConfigurations rvrConfigs) {
		if(this.roverConfigurations== null)
			this.roverConfigurations=rvrConfigs;
		if(!(roverConfigurations.getInventory()==null) && roverConfigurations.getInventory().size()>0)
			inventoryMap.put(roverConfigurations.getInventory().get(0).getType(), roverConfigurations.getInventory().get(0));
		if(location==null) {
			location= new Location();
			DeployPoint dp=roverConfigurations.getDeployPoint();
			location.setColumn(dp.getColumn());
			location.setRow(dp.getRow());
			battery=roverConfigurations.getInitialBattery();
		}
		++curSize;

	}

	public void move(Directions directions) throws RoverException {
		if(EnvironmentService.environment.isStorm())
			throw new RoverException("Cannot move during a storm");
		
				
		if(battery==0)
			throw new RoverException("Low Battery");
		if("up".equals(directions.getDirection())) {
			int currRow=location.getRow();
			if(currRow<EnvironmentService.maxRow)
				location.setRow(++currRow);
			else
				throw new RoverException("Can move only within mapped area");
			--battery;
			++steps;
		}else if("down".equals(directions.getDirection())) {
			int currRow=location.getRow();
			if(currRow>0)
				location.setRow(--currRow);
			else
				throw new RoverException("Can move only within mapped area");
			--battery;
			++steps;
		}else if("right".equals(directions.getDirection())) {
			int curColumn=location.getRow();
			if(curColumn<EnvironmentService.maxColumn)
				location.setColumn(++curColumn);
			else
				throw new RoverException("Can move only within mapped area");
			--battery;
			++steps;
		}else if("left".equals(directions.getDirection())) {
			int curColumn=location.getRow();
			if(curColumn<0)
				location.setColumn(--curColumn);
			else
				throw new RoverException("Can move only within mapped area");
			--battery;
			++steps;
		}
		if(steps%10==0)
			battery=10;
		String terrain=EnvironmentService.environment.getAreaMap().get(location.getRow()).get(location.getColumn()).getValue();
		if ("water".equals(terrain) || "rock".equals(terrain)) {
			if(curSize>maxSize) {
				removeLowProirtyQunatities(terrain);
			}
			if (!inventoryMap.containsKey(terrain)) {
				Inventory inv = new Inventory();
				inv.setQuantity(1);
				inv.setType(terrain);
				int priority="water".equals(terrain)?2:3;
				inv.setPriority(priority);
				inventoryMap.put(terrain, inv);
				++curSize;
			} else {
				Inventory inv = inventoryMap.get(terrain);
				int quantity = inv.getQuantity();
				inv.setQuantity(++quantity);
				inventoryMap.put(terrain, inv);
				++curSize;
			}
		}
	}

	private void removeLowProirtyQunatities(String terrain) {
		int priority=map.get(terrain);
		if(priority==2) {
			map.remove("storm-sheild");
			--curSize;
			return;
		} else if (priority == 3) {
			for (Inventory i : inventoryMap.values()) {
				if (i.getPriority() < priority) {
					int qunatity = i.getQuantity();
					if (qunatity > 1)
						i.setQuantity(--qunatity);
					else if(qunatity==1)
						inventoryMap.remove(i.getType());
					--curSize;
					return;
				}
			}
			Inventory i=inventoryMap.get("rock");
			int quantity=i.getQuantity();
			i.setQuantity(--quantity);
			--curSize;
		}
	}

	public RoverStatus getStatus() {
		RoverStatus roverStatus= new RoverStatus();
		RoverResponse response= new RoverResponse();
		ResponseEnvironment env= new ResponseEnvironment();
		response.setBattery(battery);
		response.setLocation(location);
		ArrayList<Inventory> list = new ArrayList<Inventory>();
		for(Inventory i:inventoryMap.values())
			list.add(i);
		response.setInventory(list);
		roverStatus.setRover(response);
		EnvironmentService.environment.setTerrain(EnvironmentService.environment.getAreaMap().get(location.getRow()).get(location.getColumn()).getValue());
		env.setHumidity(EnvironmentService.environment.getHumidity());
		env.setSolarFlare(EnvironmentService.environment.isSolarFlare());
		env.setStorm(EnvironmentService.environment.isStorm());
		env.setTemperature(EnvironmentService.environment.getTemperature());
		env.setTerrain(EnvironmentService.environment.getTerrain());
		roverStatus.setEnvironment(env);
		return roverStatus;
	}
}
