package com.azira.rover.services;

public class RoverException extends Exception {
	private static final long serialVersionUID = 1L;

	public RoverException(String msg) {
		super(msg);
	}

}
