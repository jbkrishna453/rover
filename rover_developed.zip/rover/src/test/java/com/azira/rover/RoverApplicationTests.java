package com.azira.rover;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoverApplicationTests {

	@Test
	void contextLoads() {
	}

}
